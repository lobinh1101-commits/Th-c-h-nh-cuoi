# iNotes - Strategy Pattern Note Management Application

Ứng dụng Quản lý ghi chú cá nhân **iNotes** xây dựng trên nền tảng **Java Web (Servlet 6.0, JSP 3.1, JSTL 3.0)** running trên **Tomcat 10.1+**, áp dụng Mẫu thiết kế **Strategy Pattern** cho phép linh hoạt chuyển đổi giữa lưu trữ vào **Cơ sở dữ liệu MySQL** và **Tệp tin văn bản (File txt)** mà không ảnh hưởng tới logic giao diện.

---

## 🏗️ Kiến Trúc Strategy Pattern
1. **Interface `NoteStrategy`**: Khai báo hợp đồng quản lý dữ liệu (`save`, `delete`, `findAll`, `search`, `findById`).
2. **Lớp `NoteDBStrategy`**: Thực thi lưu trữ & truy vấn trên MySQL Database bằng JDBC.
3. **Lớp `NoteFileStrategy`**: Thực thi lưu trữ & đọc ghi dữ liệu trên tệp tin văn bản `inotes_data.txt`.
4. **Lớp `NoteManagement`**: Context chứa tham chiếu `NoteStrategy strategy`, gọi phương thức `setStrategy()` để thay đổi tầng lưu trữ linh hoạt tại runtime.

---

## 📁 Cấu Trúc Thư Mục
```plaintext
inotes-app/
├── pom.xml                                  # Quản lý thư viện Maven
├── schema.sql                               # Script tạo CSDL MySQL
├── README.md                                # Tài liệu hướng dẫn
└── src/
    └── main/
        ├── java/
        │   └── com/
        │       └── codegym/
        │           ├── model/
        │           │   ├── Note.java        # Class đối tượng Ghi chú
        │           │   └── NoteType.java    # Class Phân loại ghi chú
        │           ├── strategy/
        │           │   ├── NoteStrategy.java     # Strategy Interface
        │           │   ├── NoteDBStrategy.java   # MySQL Storage Strategy
        │           │   └── NoteFileStrategy.java # File Storage Strategy
        │           ├── service/
        │           │   └── NoteManagement.java   # Service Context Manager
        │           ├── util/
        │           │   └── DBConnection.java     # JDBC Connection Manager
        │           └── controller/
        │               └── NoteServlet.java      # Servlet Điều hướng
        └── webapp/
            ├── note-list.jsp                # Dashboard danh sách & tìm kiếm
            ├── note-form.jsp                # Form Thêm mới / Cập nhật
            ├── note-detail.jsp              # Xem chi tiết ghi chú
            └── WEB-INF/
                └── web.xml                  # Cấu hình WebApp
```

---

## 🛠️ Hướng Dẫn Cài Đặt & Chạy Ứng Dụng

### Bước 1: Khởi tạo Cơ sở dữ liệu MySQL
1. Mở MySQL Workbench / phpMyAdmin.
2. Chạy toàn bộ file `schema.sql` để tạo database `inotes_db` và các bảng mẫu.
3. Mở file `src/main/java/com/codegym/util/DBConnection.java` và chỉnh sửa thông tin kết nối `USER` và `PASSWORD` cho phù hợp với máy của bạn.

### Bước 2: Đóng gói dự án
Chạy lệnh Maven trong terminal thư mục dự án:
```bash
mvn clean package
```
*Dự án sẽ đóng gói thành file `target/inotes-app.war`.*

### Bước 3: Triển khai lên Tomcat 10.1+
Deploy file `inotes-app.war` lên Tomcat 10.1+ và truy cập địa chỉ:
- `http://localhost:8080/inotes-app/`

---

## 🧪 Kiểm Thử Tính Năng Chuyển Đổi Storage (Strategy Pattern)
1. Truy cập giao diện chính, ở góc trên bên phải nhấn nút **"Chuyển nguồn lưu trữ"**.
2. Hệ thống sẽ ngay lập tức chuyển đổi nguồn dữ liệu giữa **Cơ sở dữ liệu (MySQL)** và **Tệp tin (Text File)**.
3. Thêm/Sửa/Xóa/Tìm kiếm ghi chú ở cả 2 nguồn để kiểm chứng tính linh hoạt của Strategy Pattern!
