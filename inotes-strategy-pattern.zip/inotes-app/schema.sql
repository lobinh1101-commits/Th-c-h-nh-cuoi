-- Khởi tạo Cơ sở dữ liệu inotes_db
CREATE DATABASE IF NOT EXISTS inotes_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inotes_db;

-- 1. Bảng note_type (Thể loại ghi chú)
CREATE TABLE IF NOT EXISTS note_type (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255)
);

-- 2. Bảng notes (Ghi chú)
CREATE TABLE IF NOT EXISTS notes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    type_id INT,
    FOREIGN KEY (type_id) REFERENCES note_type(id) ON DELETE SET NULL
);

-- Chèn dữ liệu mẫu cho note_type
INSERT INTO note_type (id, name, description) VALUES
(1, 'Cá nhân', 'Ghi chú công việc cá nhân, nhật ký'),
(2, 'Công việc', 'Lịch họp, công việc dự án'),
(3, 'Học tập', 'Kiến thức lập trình, bài tập');

-- Chèn dữ liệu mẫu cho notes
INSERT INTO notes (title, content, type_id) VALUES
('Họp giao ban đầu tuần', 'Chuẩn bị báo cáo tiến độ dự án iNotes cho team', 2),
('Ôn tập Design Pattern Servlet', 'Học mẫu thiết kế Strategy Pattern và ứng dụng trong Java Web', 3),
('Mua sắm cuối tuần', 'Mua hoa quả, sữa chua và đồ gia dụng', 1);
