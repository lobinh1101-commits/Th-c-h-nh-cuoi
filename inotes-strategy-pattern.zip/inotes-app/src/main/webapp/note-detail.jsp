<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chi Tiết Ghi Chú - iNotes</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; padding: 20px; }
        .card { max-width: 650px; margin: 40px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h2 { color: #1b2a7a; margin-bottom: 15px; }
        .meta { font-size: 14px; color: #6c757d; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .content { font-size: 16px; line-height: 1.6; color: #333; white-space: pre-wrap; background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .btn-back { background: #1b2a7a; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; }
    </style>
</head>
<body>

<div class="card">
    <h2>${note.title}</h2>
    <div class="meta">
        <strong>Phân loại:</strong> ${note.typeName}
    </div>
    <div class="content">${note.content}</div>
    <a href="notes" class="btn-back">Quay lại danh sách</a>
</div>

</body>
</html>
