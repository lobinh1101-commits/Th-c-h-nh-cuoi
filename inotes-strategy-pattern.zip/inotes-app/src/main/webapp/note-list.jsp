<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>iNotes Dashboard - Danh Sách Ghi Chú</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; color: #333; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 20px; border-bottom: 2px solid #eef2f5; margin-bottom: 20px; }
        .header h1 { color: #1b2a7a; font-size: 28px; }
        .badge-storage { background: #e3f2fd; color: #0d47a1; padding: 8px 15px; border-radius: 20px; font-weight: bold; font-size: 14px; display: inline-flex; align-items: center; gap: 8px; }
        .btn-switch { background: #6c757d; color: white; padding: 8px 14px; text-decoration: none; border-radius: 6px; font-size: 13px; font-weight: bold; transition: 0.2s; }
        .btn-switch:hover { background: #495057; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; gap: 15px; }
        .search-box { display: flex; flex: 1; max-width: 400px; }
        .search-box input { flex: 1; padding: 10px 14px; border: 1px solid #ced4da; border-radius: 6px 0 0 6px; font-size: 14px; outline: none; }
        .search-box button { padding: 10px 18px; background: #1b2a7a; color: white; border: none; border-radius: 0 6px 6px 0; cursor: pointer; font-weight: bold; }
        .btn-add { background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; }
        .btn-add:hover { background: #218838; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e9ecef; }
        th { background-color: #f8f9fa; color: #495057; font-weight: bold; }
        tr:hover { background-color: #f1f3f5; }
        .type-badge { padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; background: #e9ecef; color: #495057; }
        .type-1 { background: #e2e3e5; color: #383d41; } /* Cá nhân */
        .type-2 { background: #cce5ff; color: #004085; } /* Công việc */
        .type-3 { background: #d4edda; color: #155724; } /* Học tập */
        .actions a { text-decoration: none; font-size: 13px; margin-right: 8px; font-weight: bold; }
        .btn-view { color: #17a2b8; }
        .btn-edit { color: #ffc107; }
        .btn-delete { color: #dc3545; }
        .empty-state { text-align: center; padding: 40px; color: #6c757d; font-style: italic; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>iNotes Dashboard</h1>
        <div>
            <span class="badge-storage">Tầng lưu trữ: ${sessionScope.storageName}</span>
            <a href="notes?action=switch-storage" class="btn-switch">Chuyển nguồn lưu trữ</a>
        </div>
    </div>

    <div class="top-bar">
        <form action="notes" method="GET" class="search-box">
            <input type="text" name="keyword" value="${keyword}" placeholder="Tìm kiếm tiêu đề hoặc nội dung...">
            <button type="submit">Tìm kiếm</button>
        </form>
        <a href="notes?action=create" class="btn-add">+ Thêm Mới Ghi Chú</a>
    </div>

    <table>
        <thead>
        <tr>
            <th style="width: 8%;">#</th>
            <th style="width: 40%;">Tiêu đề</th>
            <th style="width: 20%;">Phân loại</th>
            <th style="width: 32%;">Thao tác</th>
        </tr>
        </thead>
        <tbody>
        <c:choose>
            <c:when test="${not empty notes}">
                <c:forEach var="note" items="${notes}" varStatus="loop">
                    <tr>
                        <td>${loop.index + 1}</td>
                        <td><strong>${note.title}</strong></td>
                        <td>
                            <span class="type-badge type-${note.typeId}">${note.typeName}</span>
                        </td>
                        <td class="actions">
                            <a href="notes?action=view&id=${note.id}" class="btn-view">Xem</a> |
                            <a href="notes?action=edit&id=${note.id}" class="btn-edit">Sửa</a> |
                            <a href="notes?action=delete&id=${note.id}" class="btn-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa ghi chú này không?');">Xóa</a>
                        </td>
                    </tr>
                </c:forEach>
            </c:when>
            <c:otherwise>
                <tr>
                    <td colspan="4" class="empty-state">Chưa có ghi chú nào trong hệ thống. Hãy thêm mới!</td>
                </tr>
            </c:otherwise>
        </c:choose>
        </tbody>
    </table>
</div>

</body>
</html>
