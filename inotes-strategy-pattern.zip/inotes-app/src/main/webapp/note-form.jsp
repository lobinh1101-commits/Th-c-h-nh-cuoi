<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>${not empty note ? "Cập Nhật Ghi Chú" : "Thêm Mới Ghi Chú"} - iNotes</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; color: #333; padding: 20px; }
        .card { max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h2 { color: #1b2a7a; margin-bottom: 20px; text-align: center; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: bold; margin-bottom: 8px; color: #495057; }
        input[type="text"], select, textarea { width: 100%; padding: 10px 14px; border: 1px solid #ced4da; border-radius: 6px; font-size: 15px; outline: none; }
        textarea { height: 140px; resize: vertical; }
        .btn-group { display: flex; justify-content: flex-end; gap: 10px; margin-top: 25px; }
        .btn-save { background: #28a745; color: white; padding: 10px 24px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; }
        .btn-save:hover { background: #218838; }
        .btn-cancel { background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; }
        .btn-cancel:hover { background: #5a6268; }
    </style>
</head>
<body>

<div class="card">
    <h2>${not empty note ? "Cập Nhật Ghi Chú" : "Thêm Mới Ghi Chú"}</h2>
    <form action="notes" method="POST">
        <input type="hidden" name="action" value="save">
        <c:if test="${not empty note}">
            <input type="hidden" name="id" value="${note.id}">
        </c:if>

        <div class="form-group">
            <label for="title">Tiêu đề Ghi chú:</label>
            <input type="text" id="title" name="title" value="${note.title}" required placeholder="Nhập tiêu đề ghi chú...">
        </div>

        <div class="form-group">
            <label for="typeId">Phân loại:</label>
            <select id="typeId" name="typeId" required>
                <c:forEach var="type" items="${noteTypes}">
                    <option value="${type.id}" ${note.typeId == type.id ? 'selected' : ''}>
                        ${type.name} - (${type.description})
                    </option>
                </c:forEach>
            </select>
        </div>

        <div class="form-group">
            <label for="content">Nội dung chi tiết:</label>
            <textarea id="content" name="content" required placeholder="Soạn thảo nội dung ghi chú...">${note.content}</textarea>
        </div>

        <div class="btn-group">
            <button type="submit" class="btn-save">Lưu Ghi Chú</button>
            <a href="notes" class="btn-cancel">Hủy bỏ</a>
        </div>
    </form>
</div>

</body>
</html>
