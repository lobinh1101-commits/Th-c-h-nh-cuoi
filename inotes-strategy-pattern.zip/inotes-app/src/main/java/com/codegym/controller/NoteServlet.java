package com.codegym.controller;

import com.codegym.model.Note;
import com.codegym.model.NoteType;
import com.codegym.service.NoteManagement;
import com.codegym.strategy.NoteDBStrategy;
import com.codegym.strategy.NoteFileStrategy;
import com.codegym.strategy.NoteStrategy;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "NoteServlet", value = "/notes")
public class NoteServlet extends HttpServlet {

    private NoteManagement noteManagement;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        initStrategy(request);

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "create":
                showCreateForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "view":
                viewNote(request, response);
                break;
            case "delete":
                deleteNote(request, response);
                break;
            case "switch-storage":
                switchStorage(request, response);
                break;
            default:
                listNotes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        initStrategy(request);

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "save":
                saveNote(request, response);
                break;
            default:
                listNotes(request, response);
                break;
        }
    }

    private void initStrategy(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String storageType = (String) session.getAttribute("storageType");

        NoteStrategy strategy;
        if ("FILE".equals(storageType)) {
            String realPath = getServletContext().getRealPath("/WEB-INF");
            strategy = new NoteFileStrategy(realPath);
        } else {
            storageType = "DB";
            strategy = new NoteDBStrategy();
        }

        session.setAttribute("storageType", storageType);
        session.setAttribute("storageName", strategy.getStorageName());

        if (noteManagement == null) {
            noteManagement = new NoteManagement(strategy);
        } else {
            noteManagement.setStrategy(strategy);
        }
    }

    private void switchStorage(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String currentStorage = (String) session.getAttribute("storageType");

        if ("DB".equals(currentStorage)) {
            session.setAttribute("storageType", "FILE");
        } else {
            session.setAttribute("storageType", "DB");
        }

        response.sendRedirect("notes");
    }

    private void listNotes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        List<Note> notes = noteManagement.searchNotes(keyword);

        request.setAttribute("notes", notes);
        request.setAttribute("keyword", keyword);

        RequestDispatcher dispatcher = request.getRequestDispatcher("note-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<NoteType> noteTypes = noteManagement.getNoteTypes();
        request.setAttribute("noteTypes", noteTypes);

        RequestDispatcher dispatcher = request.getRequestDispatcher("note-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Note note = noteManagement.getNoteById(id);
        List<NoteType> noteTypes = noteManagement.getNoteTypes();

        request.setAttribute("note", note);
        request.setAttribute("noteTypes", noteTypes);

        RequestDispatcher dispatcher = request.getRequestDispatcher("note-form.jsp");
        dispatcher.forward(request, response);
    }

    private void viewNote(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Note note = noteManagement.getNoteById(id);
        request.setAttribute("note", note);

        RequestDispatcher dispatcher = request.getRequestDispatcher("note-detail.jsp");
        dispatcher.forward(request, response);
    }

    private void saveNote(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String idStr = request.getParameter("id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        int typeId = Integer.parseInt(request.getParameter("typeId"));

        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            noteManagement.updateNote(id, title, content, typeId);
        } else {
            noteManagement.addNote(title, content, typeId);
        }

        response.sendRedirect("notes");
    }

    private void deleteNote(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        noteManagement.deleteNote(id);
        response.sendRedirect("notes");
    }
}
