package com.codegym.strategy;

import com.codegym.model.Note;
import com.codegym.model.NoteType;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class NoteFileStrategy implements NoteStrategy {

    private final String filePath;

    public NoteFileStrategy(String realPath) {
        this.filePath = realPath + File.separator + "inotes_data.txt";
        initFile();
    }

    private synchronized void initFile() {
        File file = new File(filePath);
        if (!file.exists()) {
            try {
                file.createNewFile();
                // Ghi dữ liệu mẫu mặc định vào file nếu mới tạo
                List<Note> sampleNotes = new ArrayList<>();
                sampleNotes.add(new Note(1, "Họp giao ban (File)", "Ghi chú lưu trong tệp tin txt", 2, "Công việc"));
                sampleNotes.add(new Note(2, "Học tập Design Pattern (File)", "Luyện tập Strategy Pattern bằng File", 3, "Học tập"));
                writeAllToFile(sampleNotes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public String getStorageName() {
        return "Tệp tin (Text File - inotes_data.txt)";
    }

    private synchronized List<Note> readAllFromFile() {
        List<Note> notes = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return notes;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split("\\|", -1);
                if (parts.length >= 5) {
                    int id = Integer.parseInt(parts[0]);
                    String title = parts[1].replace("<BR>", "\n");
                    String content = parts[2].replace("<BR>", "\n");
                    int typeId = Integer.parseInt(parts[3]);
                    String typeName = parts[4];
                    notes.add(new Note(id, title, content, typeId, typeName));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return notes;
    }

    private synchronized void writeAllToFile(List<Note> notes) {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath, false), StandardCharsets.UTF_8))) {
            for (Note n : notes) {
                String cleanTitle = n.getTitle() != null ? n.getTitle().replace("\n", "<BR>").replace("\r", "") : "";
                String cleanContent = n.getContent() != null ? n.getContent().replace("\n", "<BR>").replace("\r", "") : "";
                String line = String.format("%d|%s|%s|%d|%s",
                        n.getId(),
                        cleanTitle,
                        cleanContent,
                        n.getTypeId(),
                        n.getTypeName() != null ? n.getTypeName() : getTypeNameById(n.getTypeId()));
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getTypeNameById(int typeId) {
        switch (typeId) {
            case 1: return "Cá nhân";
            case 2: return "Công việc";
            case 3: return "Học tập";
            default: return "Khác";
        }
    }

    @Override
    public synchronized void save(Note note) {
        List<Note> notes = readAllFromFile();
        if (note.getId() > 0) {
            // Update
            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).getId() == note.getId()) {
                    note.setTypeName(getTypeNameById(note.getTypeId()));
                    notes.set(i, note);
                    break;
                }
            }
        } else {
            // Insert (Generate auto ID)
            int maxId = 0;
            for (Note n : notes) {
                if (n.getId() > maxId) maxId = n.getId();
            }
            note.setId(maxId + 1);
            note.setTypeName(getTypeNameById(note.getTypeId()));
            notes.add(0, note);
        }
        writeAllToFile(notes);
    }

    @Override
    public synchronized void delete(int id) {
        List<Note> notes = readAllFromFile();
        notes.removeIf(n -> n.getId() == id);
        writeAllToFile(notes);
    }

    @Override
    public List<Note> findAll() {
        return readAllFromFile();
    }

    @Override
    public List<Note> search(String keyword) {
        List<Note> all = readAllFromFile();
        List<Note> result = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) return all;
        String lowerKey = keyword.toLowerCase();
        for (Note n : all) {
            if ((n.getTitle() != null && n.getTitle().toLowerCase().contains(lowerKey)) ||
                (n.getContent() != null && n.getContent().toLowerCase().contains(lowerKey))) {
                result.add(n);
            }
        }
        return result;
    }

    @Override
    public Note findById(int id) {
        List<Note> all = readAllFromFile();
        for (Note n : all) {
            if (n.getId() == id) return n;
        }
        return null;
    }

    @Override
    public List<NoteType> getNoteTypes() {
        List<NoteType> list = new ArrayList<>();
        list.add(new NoteType(1, "Cá nhân", "Ghi chú cá nhân"));
        list.add(new NoteType(2, "Công việc", "Ghi chú công việc"));
        list.add(new NoteType(3, "Học tập", "Ghi chú học tập"));
        return list;
    }
}
