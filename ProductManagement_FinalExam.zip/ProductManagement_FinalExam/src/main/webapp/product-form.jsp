<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>${not empty product ? 'Cập Nhật Sản Phẩm' : 'Thêm Sản Phẩm Mới'}</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; color: #333; padding: 30px; }
        .card { max-width: 500px; margin: 40px auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h2 { color: #1b2a7a; margin-bottom: 20px; text-align: center; }
        .form-group { margin-bottom: 18px; }
        label { display: block; font-weight: bold; margin-bottom: 8px; color: #495057; }
        input[type="text"], input[type="number"] { width: 100%; padding: 10px 14px; border: 1px solid #ced4da; border-radius: 6px; font-size: 15px; outline: none; }
        .btn-group { display: flex; justify-content: flex-end; gap: 10px; margin-top: 25px; }
        .btn-save { background-color: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; }
        .btn-save:hover { background-color: #218838; }
        .btn-cancel { background-color: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; }
        .btn-cancel:hover { background-color: #5a6268; }
    </style>
</head>
<body>

<div class="card">
    <h2>${not empty product ? 'Cập Nhật Sản Phẩm' : 'Thêm Sản Phẩm Mới'}</h2>
    <form action="products" method="POST">
        <c:if test="${not empty product}">
            <input type="hidden" name="action" value="update" />
            <input type="hidden" name="id" value="${product.id}" />
        </c:if>
        <c:if test="${empty product}">
            <input type="hidden" name="action" value="insert" />
        </c:if>

        <div class="form-group">
            <label for="name">Tên Sản Phẩm:</label>
            <input type="text" id="name" name="name" value="${product.name}" required placeholder="Nhập tên sản phẩm..." />
        </div>

        <div class="form-group">
            <label for="price">Giá ($):</label>
            <input type="number" id="price" name="price" step="0.01" min="0" value="${product.price}" required placeholder="Nhập giá sản phẩm..." />
        </div>

        <div class="form-group">
            <label for="quantity">Số Lượng:</label>
            <input type="number" id="quantity" name="quantity" min="0" value="${product.quantity}" required placeholder="Nhập số lượng sản phẩm..." />
        </div>

        <div class="btn-group">
            <button type="submit" class="btn-save">${not empty product ? 'Lưu Cập Nhật' : 'Tạo Mới'}</button>
            <a href="products" class="btn-cancel">Hủy Bỏ</a>
        </div>
    </form>
</div>

</body>
</html>
