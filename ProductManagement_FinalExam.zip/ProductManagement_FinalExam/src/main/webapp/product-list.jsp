<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Sản Phẩm - Danh Sách</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; color: #333; padding: 30px; }
        .container { max-width: 1000px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; border-bottom: 2px solid #eef2f5; padding-bottom: 15px; }
        .header h2 { color: #1b2a7a; }
        .btn-add { background-color: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; transition: 0.2s; }
        .btn-add:hover { background-color: #218838; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e9ecef; }
        th { background-color: #3498db; color: white; font-weight: bold; }
        tr:hover { background-color: #f8f9fa; }
        .actions a { text-decoration: none; font-size: 13px; font-weight: bold; padding: 5px 10px; border-radius: 4px; margin-right: 5px; }
        .btn-edit { background-color: #ffc107; color: #212529; }
        .btn-edit:hover { background-color: #e0a800; }
        .btn-delete { background-color: #dc3545; color: white; }
        .btn-delete:hover { background-color: #c82333; }
        .price { color: #e74c3c; font-weight: bold; }
        .empty-state { text-align: center; padding: 30px; color: #6c757d; font-style: italic; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Hệ Thống Quản Lý Sản Phẩm</h2>
        <a href="products?action=new" class="btn-add">+ Thêm Sản Phẩm Mới</a>
    </div>

    <table>
        <thead>
        <tr>
            <th style="width: 10%;">ID</th>
            <th style="width: 40%;">Tên Sản Phẩm</th>
            <th style="width: 20%;">Giá ($)</th>
            <th style="width: 15%;">Số Lượng</th>
            <th style="width: 15%;">Thao Tác</th>
        </tr>
        </thead>
        <tbody>
        <c:choose>
            <c:when test="${not empty listProduct}">
                <c:forEach var="product" items="${listProduct}">
                    <tr>
                        <td>${product.id}</td>
                        <td><strong>${product.name}</strong></td>
                        <td class="price">$${product.price}</td>
                        <td>${product.quantity}</td>
                        <td class="actions">
                            <a href="products?action=edit&id=${product.id}" class="btn-edit">Sửa</a>
                            <a href="products?action=delete&id=${product.id}" class="btn-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm [${product.name}] không?');">Xóa</a>
                        </td>
                    </tr>
                </c:forEach>
            </c:when>
            <c:otherwise>
                <tr>
                    <td colspan="5" class="empty-state">Chưa có sản phẩm nào trong cơ sở dữ liệu.</td>
                </tr>
            </c:otherwise>
        </c:choose>
        </tbody>
    </table>
</div>

</body>
</html>
