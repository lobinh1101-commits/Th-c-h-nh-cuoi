-- Khởi tạo Cơ sở dữ liệu product_db
CREATE DATABASE IF NOT EXISTS product_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE product_db;

-- Tạo bảng products
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    quantity INT NOT NULL
);

-- Chèn dữ liệu mẫu
INSERT INTO products (name, price, quantity) VALUES
('iPhone 15 Pro Max', 1199.00, 15),
('Samsung Galaxy S24 Ultra', 1299.50, 20),
('MacBook Pro M3 Max', 2499.00, 8),
('Dell XPS 15', 1599.99, 12);
