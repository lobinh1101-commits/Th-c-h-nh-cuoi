# Product Management Final Exam - Java Web Application

Ứng dụng Web Quản lý sản phẩm CRUD hoàn chỉnh xây dựng bằng **Java Servlet, JSP, JSTL, JDBC** và **MySQL Database**, chạy trên **Apache Tomcat 10.1+** (Jakarta EE 10).

## 📌 Tính năng chính
1. **Hiển thị danh sách sản phẩm**: Hiển thị bảng sản phẩm gồm ID, Tên, Giá, Số lượng.
2. **Thêm sản phẩm mới**: Form nhập liệu thông tin sản phẩm và lưu vào MySQL DB.
3. **Sửa thông tin sản phẩm**: Chọn sản phẩm, load dữ liệu cũ lên form và thực hiện cập nhật.
4. **Xóa sản phẩm**: Xóa sản phẩm khỏi DB có xác nhận JavaScript (Confirm box).
5. **Cơ sở dữ liệu**: Sử dụng MySQL JDBC Driver kết nối tới database `product_db`.

## 📁 Cấu trúc dự án
```plaintext
ProductManagement_FinalExam/
├── pom.xml                                  # File cấu hình phụ thuộc Maven
├── schema.sql                               # Script tạo CSDL MySQL
├── README.md                                # Tài liệu hướng dẫn
└── src/
    └── main/
        ├── java/
        │   └── com/
        │       └── codegym/
        │           ├── model/
        │           │   └── Product.java     # Entity Lớp Sản phẩm
        │           ├── dao/
        │           │   └── ProductDAO.java  # Tầng truy xuất CSDL JDBC
        │           ├── util/
        │           │   └── DBConnection.java# Kết nối MySQL
        │           └── controller/
        │               └── ProductServlet.java # Controller Servlet CRUD
        └── webapp/
            ├── product-list.jsp             # Trang danh sách sản phẩm
            ├── product-form.jsp             # Trang Form Thêm/Sửa sản phẩm
            └── WEB-INF/
                └── web.xml                  # Cấu hình WebApp
```

## 🛠️ Hướng Dẫn Khởi Chạy

### 1. Khởi tạo Cơ sở dữ liệu MySQL
- Mở MySQL Workbench / phpMyAdmin.
- Chạy toàn bộ file `schema.sql` để tạo CSDL `product_db` và bảng `products`.
- Kiểm tra lại mật khẩu MySQL trong `DBConnection.java` (mặc định là `root`).

### 2. Đóng gói dự án Maven
```bash
mvn clean package
```
Tệp `.war` sẽ được sinh ra tại `target/ProductManagement_FinalExam.war`.

### 3. Triển khai lên Tomcat 10.1+
Deploy tệp `ProductManagement_FinalExam.war` vào thư mục `webapps/` của Tomcat 10.1+ và truy cập:
`http://localhost:8080/ProductManagement_FinalExam/`
